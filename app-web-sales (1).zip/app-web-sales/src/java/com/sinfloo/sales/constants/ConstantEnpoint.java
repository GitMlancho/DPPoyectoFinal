
package com.sinfloo.sales.constants;


public class ConstantEnpoint {
    
    public static final String GET="GET";
    public static final String POST="POST";
    
    public static final String LOGIN="/login";
    public static final String LOGOUT="/logout";
    
}
