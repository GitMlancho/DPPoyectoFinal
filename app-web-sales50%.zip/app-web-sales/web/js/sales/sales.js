$("#linkSales").click(function () {
    $("#title").html('<i class="bi bi-cart4"></i> Modulo de Ventas');
    $("#contenido").empty();
    $("#contenido").load("/app-web-sales/sale/", function () {
        getSale();
    });
});

function getSale() {
    console.log("Iniciando nueva venta");
}

$(document).on('click', '#btnSearchProduct', function () {
    var productCode = $("#productCode").val();
    var url = "/app-web-sales/mnto/product/obtain/code/?code=" + productCode;

    fetch(url).then(response => {
        if (!response.ok) {
            throw new Error('Error al consumir el controlador');
        }
        return response.json();
    }).then(data => {
        console.log("data", data);
        if (data.code === "200") {
            $("#productId").val(data.product.productId);
            $("#productName").val(data.product.name);
            $("#productDescription").val(data.product.description);
            $("#productPrice").val(data.product.price);
            $("#productStock").val(data.product.stock);
        } else {
            showToast("error", data.message);
        }
    }).catch(error => {
        showToast("error", error);
    });
});

$(document).on('click', '#btnSearchCustomer', function () {
    var url = "/app-web-sales/sale/obtain/customer";
    var formData = {};
    formData["typedoc"] = $("#typedoc").val();
    formData["numdoc"] = $("#numdoc").val();

    fetch(url, {
        method: 'POST',
        body: JSON.stringify(formData),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => {
        if (!response.ok) {
            throw new Error('Error al consumir el controlador');
        }
        return response.json();
    }).then(data => {
        if (data.code === "200") {
            console.log("sale", data.sale);
            $("#typedoc opcion[value='" + data.sale.customer.typeDoc + ']').prop('selected', true);
            $("#numDoc").val(data.sale.customer.numDoc);
            $("#customerName").val(data.sale.customer.name + ' ' + data.sale.customer.firstName + ' ' + data.sale.customer.lastName);
            showSale();
        } else {
            Swal.fire({
                title: "Mensaje",
                text: data.message,
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "SI",
                cancelButtonText: "NO"
            }).then((result) => {
                if (result.isConfirmed) {
                    $("#contentModalCustomer").empty();
                    $("#contentModalCustomer").load("/app-web-sales/mnto/customer/edit", function () {
                        $("#modalAddCustomer").modal("show");
                    });
                }
            });
        }
    }).catch(error => {
        console.log("Error:", error);
    });
});

$(document).on('click', '#btnAddProductoToCart', function () {
    
    var url = "/app-web-sales/sale/add";

    var dataSaleDetailProd = {};
    dataSaleDetailProd["productId"] = $("#productId").val();
    dataSaleDetailProd["code"] = $("#productCode").val();
    dataSaleDetailProd["name"] = $("#productName").val();
    dataSaleDetailProd["description"] = $("#productDescription").val();
    dataSaleDetailProd["price"] = $("#productPrice").val();
    dataSaleDetailProd["stock"] = $("#productStock").val();


    var dataSaleDetail = {};
    dataSaleDetail["product"] = dataSaleDetailProd;
    dataSaleDetail["price"] = $("#productPrice").val();
    dataSaleDetail["quanty"] = $("#productQuanty").val();

    fetch(url, {
        method: 'POST',
        body: JSON.stringify(dataSaleDetail),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => {
        if (!response.ok) {
            throw new Error('Error al consumir el controlador');
        }
        return response.json();
    }).then(data => {
        console.log("data", data);
        if (data.code === "200") {
            showToast("success", data.message);
            showSale(data.sale);
        } else {
            showToast("error", data.message);
        }
    }).catch(error => {
        showToast("error", error);
    });
});
function showSale(sale) {
    $('#tableCart tbody').empty();
    if(sale.details.length>0){
       $.each(sale.details, function (index, value) {
        var row = $('<tr>');
        row.append($('<td class="text-center">').text(index + 1));
        row.append($('<td class="text-center">').text(value.product.code));
        row.append($('<td>').text(value.product.name));
        row.append($('<td class="text-center">').text(value.price));
        row.append($('<td class="text-center">').text(value.quanty));
        row.append($('<td class="text-center">').text(value.total));
        row.append($('<td class="text-center">')
                .append('<a class="btn btn-danger btn-sm ms-1" onclick="deleteProduct(' + value.product.productId + ')"><i class="bi bi-trash"></i></a>'));
        $("#tableCart tbody").append(row);
    });
    }
    if(sale.customer !== null){
        $("#montoNeto").text(sale.amount_net.toFixed(2));
        $("#montoIgv").text(sale.amount_iva.toFixed(2));
        $("#montoTotal").text(sale.amount_total.toFixed(2));
    }
}